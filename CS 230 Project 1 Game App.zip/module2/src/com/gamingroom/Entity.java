package com.gamingroom;

/**
 * A simple class to hold information about players, teams, and games
 *
 * @author Bryan Pirrone
 * May 21, 2023
 *
 */

public class Entity {
	//sets protected attributes so subclasses can inherit
	protected long id;
	protected String name;
	
	//set protected so subclasses can call
	protected Entity() {}
	
	public Entity(long id, String name) {
		
		this.id = id;
		this.name = name;
	}
	
	public long getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Entity [id=" + id + ", name=" + name + "]";
	}
}
