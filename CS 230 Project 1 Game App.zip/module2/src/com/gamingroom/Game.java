package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 * @author Bryan Pirrone
 * May 21, 2023
 *
 */
public class Game extends Entity {
	
	private static List<Team> teams = new ArrayList<Team>();
	
	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Game() {
	}

	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}

	public Team addTeam(String name) {
		Team tempTeam = null;

		//loop to search for teams
		//checks for existence of team
		
		for (Team currTeam : teams) {
			if (currTeam.name.equalsIgnoreCase(name)) {
				return currTeam;
			}
		}
		
		//if a team isn't found, create it
		//create the new team
		//calls GameService to get new teamID
		
		GameService tempService = GameService.getGameService();
		
		tempTeam = new Team(tempService.getNextTeamId(), name);
		
		//adds the new team to the list of teams for the game
		
		teams.add(tempTeam);
		
		return tempTeam;
	}

	@Override
	public String toString() {
		
		return "Game [id=" + id + ", name=" + name + "]";
	}

}
